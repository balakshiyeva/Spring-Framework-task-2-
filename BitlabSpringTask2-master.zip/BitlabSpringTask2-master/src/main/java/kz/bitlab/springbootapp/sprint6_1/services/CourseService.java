package kz.bitlab.springbootapp.sprint6_1.services;

import kz.bitlab.springbootapp.sprint6_1.models.Course;

import java.util.List;

public interface CourseService {
    List<Course> getAll();

}
